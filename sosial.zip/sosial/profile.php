<?php
require('backend/log.php');
require('config/db.mysql.php');

$log = new Logger();

if (isset($_GET['email'])) {
    $email = htmlspecialchars($_GET['email']);

    if (empty($email)) {
        echo $log->log(400, 'Email kosong!');
    } else {
        $query = "SELECT * FROM users WHERE email = ?";
        $check = $con->prepare($query);

        if ($check) {
            $check->bind_param('s', $email);

            if ($check->execute()) {
                $result = $check->get_result();

                if ($result->num_rows != 0) {
                    $data = [];

                    while ($row = $result->fetch_assoc()) {
                        $data[] = $row;
                    }

                    echo $log->logcat(200, 'OK', $data);
                } else {
                    echo $log->log(404, 'Akun tidak ditemukan!');
                }
            } else {
                echo $log->log(500, 'Gagal mengeksekusi query!');
            }

            $check->close(); // Close the prepared statement
        } else {
            echo $log->log(500, 'Gagal menyiapkan query!');
        }
    }
} else {
    echo $log->log(400, 'Parameter email tidak ditemukan!');
}

$con->close(); // Close the database connection
?>
