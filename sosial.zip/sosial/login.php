<?php
require('config/db.mysql.php');
require('backend/log.php');

$log = new Logger();

if (isset($_POST['email'], $_POST['pass'])) {
    $email = htmlspecialchars($_POST['email']);
    $pass = htmlspecialchars($_POST['pass']);

    if (empty($email) || empty($pass)) {
        echo $log->log(400, 'Email or password cannot be empty');
    } else {
        $query = "SELECT * FROM users WHERE email = ?";
        $login = $con->prepare($query);

        if ($login) {
            $login->bind_param('s', $email);

            if ($login->execute()) {
                $result = $login->get_result();

                if ($result->num_rows != 0) {
                    $row = $result->fetch_assoc();

                    if (password_verify($pass, $row['password'])) {
                        echo $log->log(200, 'Login successful');
                    } else {
                        echo $log->log(401, 'Login failed: Incorrect password');
                    }
                } else {
                    echo $log->log(404, 'Account does not exist');
                }
            } else {
                echo $log->log(500, 'Database query execution failed');
            }

            $login->close(); // Close the prepared statement
        } else {
            echo $log->log(500, 'Database query preparation failed');
        }
    }
} else {
    echo $log->log(400, 'Email and password are required');
}

$con->close(); // Close the database connection
?>
