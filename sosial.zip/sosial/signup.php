<?php
require('config/db.mysql.php');
require('backend/log.php');

$log = new Logger();

if (isset($_POST['nama'], $_POST['email'], $_POST['pass'], $_POST['hobi'], $_POST['komunitas'])) {
    $nama = $con->real_escape_string(trim($_POST['nama']));
    $email = $con->real_escape_string(trim($_POST['email']));
    $pass = $con->real_escape_string(trim($_POST['pass']));
    $hobi = $con->real_escape_string(trim($_POST['hobi']));
    $komunitas = $con->real_escape_string(trim($_POST['komunitas']));

    if (empty($nama) || empty($email) || empty($pass)) {
        echo $log->log(400, 'Input ada yang kosong!');
    } else {
        $check = $con->prepare('SELECT * FROM users WHERE email = ?');
        $check->bind_param('s', $email);
        if ($check->execute()) {
            $res = $check->get_result();
            if ($res->num_rows == 0) {
                $pass_hash = password_hash($pass, PASSWORD_DEFAULT);

                $query = "INSERT INTO users (nama, email, hobi, komunitas, password) VALUES (?, ?, ?, ?, ?)";
                $add = $con->prepare($query);

                if ($add) {
                    $add->bind_param('sssss', $nama, $email, $hobi, $komunitas, $pass_hash);

                    if ($add->execute()) {
                        echo $log->log(200, 'Berhasil membuat akun!');
                    } else {
                        echo $log->log(500, 'Gagal membuat akun!');
                    }

                    $add->close();
                } else {
                    echo $log->log(500, 'Gagal membuat query!');
                }
            }else{
                echo $log->log(500, 'akun sudah terdaftar!');
            }
        }
    }
} else {
    echo $log->log(400, 'Parameter tidak lengkap!');
}

$con->close();
