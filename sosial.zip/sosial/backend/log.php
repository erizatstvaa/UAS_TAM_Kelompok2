<?php
class Logger {
    public function __construct(){
        header("Content-Type: application/json");
    }
    public function logcat($code, $message, $array = []){
        echo json_encode(array(
            'code' => $code,
            'message' => $message,
            'data' => $array
        ));
    }
    public function log($code, $message){
        echo json_encode(array(
            'code' => $code,
            'message' => $message
        ));
    }
}